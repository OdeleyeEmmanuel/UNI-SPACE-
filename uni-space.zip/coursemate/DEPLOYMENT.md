# Deploying Uni Space

This covers three things: running it **locally**, pushing it to **GitHub**, and
putting it on the **public internet** — all connected to the one live Supabase
project (`hrrhqsspwoeedsuszaix`) that already has your real schema, RLS, and data.

---

## 1. Run it locally

You need [Node.js 18+](https://nodejs.org) installed.

```bash
unzip coursemate.zip
cd coursemate
npm install
cp .env.example .env
npm run dev
```

Open the URL it prints (usually `http://localhost:5173`). This talks directly to
your live Supabase project over the internet — there's no local database to set
up. Sign up, go through onboarding, everything you do here writes to the real
`hrrhqsspwoeedsuszaix` project.

`.env` is already filled with the project URL and the **anon/publishable key**
(safe to expose — RLS is what actually protects data). It's git-ignored so it
won't get committed.

---

## 2. Put it on GitHub

```bash
cd coursemate
git init
git add .
git commit -m "Uni Space: Phases 1–9"
```

Create an empty repo on GitHub (github.com → New repository → don't initialize
with a README, since you already have one), then:

```bash
git remote add origin https://github.com/<your-username>/coursemate.git
git branch -M main
git push -u origin main
```

Your `.env` file (with real keys) is excluded by `.gitignore` — only
`.env.example` gets committed, so nothing sensitive lands on GitHub.

### Linking GitHub to Supabase (so schema changes deploy automatically)

This connects your *database migrations* — not the frontend — to GitHub, so
that when you or I add new tables/policies as files in `supabase/migrations/`,
pushing to `main` applies them automatically instead of running them by hand.

1. Install the Supabase CLI locally: `npm install -g supabase`
2. `supabase login`
3. From the `coursemate` folder: `supabase link --project-ref hrrhqsspwoeedsuszaix`
4. In the Supabase dashboard → **Project Settings → Integrations → GitHub**,
   connect the `coursemate` repo and point it at the `main` branch.
5. Pull the current schema into your repo so it's tracked in git:
   `supabase db pull` — this creates a `supabase/migrations/` folder with everything
   already built (all the Phase 1–9 tables, RLS policies, functions).

After this, future schema changes go: write a migration file → push to GitHub →
Supabase applies it automatically. You can also just keep asking me to run
migrations directly against the project, which is what I've been doing — both
approaches work on the same database.

---

## 3. Deploy it publicly

The spec calls for Vercel, so here's that path (Netlify works almost
identically if you'd rather use that).

### Vercel (recommended)

1. Go to [vercel.com](https://vercel.com), sign in with GitHub.
2. **Add New → Project**, select your `coursemate` repo.
3. Framework preset: Vercel auto-detects **Vite** — leave the defaults
   (build command `npm run build`, output directory `dist`).
4. Add environment variables (**Settings → Environment Variables**):
   - `VITE_SUPABASE_URL` = `https://hrrhqsspwoeedsuszaix.supabase.co`
   - `VITE_SUPABASE_ANON_KEY` = `sb_publishable_igsZYOgfTXWsHjPBzylotg__j99SF_Z`
5. **Deploy.**

You'll get a live URL like `coursemate.vercel.app` within a minute or two.
Every future `git push` to `main` auto-redeploys.

### A few things to set up in Supabase before going fully public

- **Auth → URL Configuration**: add your Vercel URL (and `http://localhost:5173`
  for local dev) to the **Redirect URLs** allow-list, or email confirmation
  links and OAuth (if you add any later) will fail.
- **Auth → Email Templates**: Supabase's default confirmation emails work out
  of the box but are rate-limited on the free tier — for real usage at scale
  you'll want to configure a custom SMTP provider (Settings → Auth → SMTP).
- **Custom domain** (optional): Vercel → Settings → Domains → add
  `coursemate.yourdomain.com` or similar, point your DNS at it per Vercel's
  instructions.

---

## How the pieces fit together

```
GitHub repo (source code)
    │
    ├── pushed to Vercel  → builds the React app → public website
    │                        (reads VITE_SUPABASE_URL / ANON_KEY at build time)
    │
    └── linked to Supabase → migrations folder → applies schema changes
                              to the SAME database the live site talks to
```

Local dev, the Vercel deployment, and your own testing all point at the one
Supabase project — there's no separate "staging" database yet. If you want
one later (recommended before this has real users), `supabase branches create`
gives you an isolated copy of the schema to test against without touching
production data.

---

## Quick sanity checklist after deploying

- [ ] Sign up on the live URL, confirm the email, complete onboarding
- [ ] Link Up with a second test account, accept it, confirm a notification appears
- [ ] Post something in the feed with an image attached
- [ ] Open a community, upload a PDF resource, download it back
- [ ] Send a message, confirm it arrives in real time in a second browser tab
- [ ] Check Supabase dashboard → Table Editor to confirm rows are actually being written
