import { useState } from 'react';

export default function AnimatedLaptop() {
  const [rotation, setRotation] = useState(0);
  const [spinning, setSpinning] = useState(false);

  const handleClick = () => {
    setRotation((r) => r + 360);
    setSpinning(true);
    window.setTimeout(() => setSpinning(false), 900);
  };

  return (
    <div className="flex flex-col items-center gap-3">
      <button
        onClick={handleClick}
        aria-label="Spin the illustration"
        className="relative outline-none focus-visible:ring-2 focus-visible:ring-gold rounded-full"
      >
        {/* Soft halo glow behind the illustration */}
        <div className="absolute inset-0 -m-6 rounded-full bg-gold/20 blur-2xl animate-halo pointer-events-none" />

        <div
          className="drop-in relative cursor-pointer"
          style={{
            transform: `rotate(${rotation}deg)`,
            transition: 'transform 0.9s cubic-bezier(0.65, 0, 0.35, 1)',
          }}
        >
          <svg width="220" height="220" viewBox="0 0 200 200" fill="none" xmlns="http://www.w3.org/2000/svg">
            {/* Laptop base / hinge */}
            <path
              pathLength={1}
              className="draw-path"
              d="M38 132 L162 132 L178 152 L22 152 Z"
              stroke="#C9A227"
              strokeWidth="3"
              strokeLinejoin="round"
              style={{ animationDelay: '0.9s' }}
            />
            {/* Screen frame */}
            <rect
              pathLength={1}
              className="draw-path"
              x="54" y="44" width="92" height="66" rx="5"
              stroke="#14213D"
              strokeWidth="3"
              style={{ animationDelay: '0.5s' }}
            />
            {/* Course-card lines inside the screen */}
            <line pathLength={1} className="draw-path" x1="66" y1="58" x2="112" y2="58" stroke="#C9A227" strokeWidth="3" strokeLinecap="round" style={{ animationDelay: '1.1s' }} />
            <line pathLength={1} className="draw-path" x1="66" y1="70" x2="132" y2="70" stroke="#14213D" strokeWidth="2" strokeLinecap="round" opacity="0.5" style={{ animationDelay: '1.2s' }} />
            <line pathLength={1} className="draw-path" x1="66" y1="80" x2="122" y2="80" stroke="#14213D" strokeWidth="2" strokeLinecap="round" opacity="0.5" style={{ animationDelay: '1.3s' }} />
            {/* Small seal badge on the screen — the "Uni Space" mark */}
            <circle pathLength={1} className="draw-path" cx="118" cy="92" r="9" stroke="#C1462F" strokeWidth="2.5" style={{ animationDelay: '1.5s' }} />
            <line pathLength={1} className="draw-path" x1="66" y1="88" x2="95" y2="88" stroke="#14213D" strokeWidth="2" strokeLinecap="round" opacity="0.5" style={{ animationDelay: '1.4s' }} />
          </svg>
        </div>
      </button>
      <p className={`font-mono text-[10px] uppercase tracking-[0.2em] text-ink-soft transition-opacity ${spinning ? 'opacity-100' : 'opacity-60'}`}>
        Tap to spin
      </p>
    </div>
  );
}
