import { FormEvent, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import AnimatedLaptop from '../components/AnimatedLaptop';

export default function Login() {
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    setLoading(false);
    if (error) {
      setError(error.message);
      return;
    }
    navigate('/home');
  };

  return (
    <div className="min-h-screen flex flex-col md:flex-row">
      {/* Left / top panel — the epic bit: ink background, drifting seals, animated illustration */}
      <div className="relative md:w-1/2 bg-ink text-paper flex flex-col items-center justify-center px-8 py-14 overflow-hidden">
        <div className="pointer-events-none absolute inset-0 overflow-hidden opacity-[0.08]">
          <div className="absolute -top-16 -left-16 w-72 h-72 rounded-full border-[16px] border-gold animate-drift" />
          <div className="absolute bottom-0 -right-20 w-96 h-96 rounded-full border-[20px] border-paper animate-drift" style={{ animationDelay: '-5s' }} />
        </div>

        <Link to="/" className="absolute top-6 left-6 md:top-8 md:left-8 flex items-center gap-2 z-10">
          <div className="seal w-8 h-8 text-[9px]">US</div>
          <span className="font-display text-base font-semibold">Uni Space</span>
        </Link>

        <div className="relative z-10 flex flex-col items-center text-center max-w-xs">
          <AnimatedLaptop />
          <h2 className="font-display text-2xl font-semibold mt-6 mb-2">
            Your course, everywhere.
          </h2>
          <p className="text-paper/70 text-sm">
            Cross-university communities, Link Ups, and shared resources — sign in to pick up where you left off.
          </p>
        </div>
      </div>

      {/* Right / bottom panel — the actual form, on the paper background */}
      <div className="md:w-1/2 bg-paper grain-bg flex items-center justify-center px-6 py-14">
        <div className="w-full max-w-sm">
          <span className="ribbon-divider mb-2 block">Welcome back</span>
          <h1 className="font-display text-3xl font-semibold mb-2">Sign in</h1>
          <p className="text-ink-soft mb-8">Enter your details to continue to Uni Space.</p>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-1.5">Email</label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full px-4 py-2.5 rounded-lg border border-ink/15 bg-white focus:border-gold outline-none transition-colors"
                placeholder="you@student.edu.ng"
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1.5">Password</label>
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full px-4 py-2.5 rounded-lg border border-ink/15 bg-white focus:border-gold outline-none transition-colors"
                placeholder="••••••••"
              />
            </div>

            {error && <p className="text-coral text-sm">{error}</p>}

            <button
              type="submit"
              disabled={loading}
              className="seal w-full py-3 rounded-lg text-sm disabled:opacity-50"
            >
              {loading ? 'Signing in…' : 'Sign in'}
            </button>
          </form>

          <p className="text-sm text-ink-soft mt-6">
            New here?{' '}
            <Link to="/auth/signup" className="text-ink font-medium underline">
              Create an account
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}
